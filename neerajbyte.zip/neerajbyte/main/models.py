from django.db import models


class Gender(models.Model):
    gender = models.CharField('Gender', max_length=50)
    def __str__(self):
        return self.gender

    class Meta:
        verbose_name = ('Gender')


class Language(models.Model):
    language = models.CharField('Language', max_length=50)
    def __str__(self):
        return self.language

    class Meta:
        verbose_name = ('Language')


class State(models.Model):
    state = models.CharField('State', max_length=50)
    def __str__(self):
        return self.state

    class Meta:
        verbose_name = ('State')


class Student(models.Model):
    full_name = models.CharField('Full Name', max_length=50)
    gender = models.ForeignKey('Gender', on_delete=models.CASCADE)
    language = models.ForeignKey('Language', on_delete=models.CASCADE)
    location = models.ForeignKey('State', on_delete=models.CASCADE)
    grades = models.CharField('Grades', max_length=2)

    def __str__(self):
        return self.full_name

    class Meta:
        verbose_name = ('Student')



class Attendence(models.Model):
    
    Student = models.ForeignKey('Student', on_delete=models.CASCADE)

    subject = models.CharField('Full Name', max_length=50)
    gender1 = models.ForeignKey('Gender', on_delete=models.CASCADE)
    language1 = models.ForeignKey('Language', on_delete=models.CASCADE)
    location1 = models.ForeignKey('State', on_delete=models.CASCADE)
    
    def __str__(self):
        return self.subject    

    class Meta:
        verbose_name = ('Attendence')

