from django.contrib import admin

from main.models import Gender,Language,State,Student,Attendence


class GenderAdmin(admin.ModelAdmin):
    display = ('gender')
    filter = ('gender')
    save_as = True
    save_on_top = True
    # change_list_template = 'change_list_graph.html'


admin.site.register(Gender, GenderAdmin)


class LanguageAdmin(admin.ModelAdmin):
    display = ('language')
    filter = ('language')
    save_as = True
    save_on_top = True
    # change_list_template = 'change_list_graph.html'


admin.site.register(Language, LanguageAdmin)


class StateAdmin(admin.ModelAdmin):
    display = ('state')
    filter = ('state')
    save_as = True
    save_on_top = True
    # change_list_template = 'change_list_graph.html'


admin.site.register(State, StateAdmin)


class StudentAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'language', 'grades', 'gender','location')
    list_filter = ('language', 'gender', 'grades','location')
    save_as = True
    save_on_top = True
    # change_list_template = 'change_list_graph.html'


admin.site.register(Student, StudentAdmin)



class AttendenceAdmin(admin.ModelAdmin):
    list_display = ('Student','subject','gender1','location1','language1')
    list_filter = ('Student','subject','gender1','location1','language1')
    save_as = True
    save_on_top = True
    change_list_template = 'change_list_graph1.html'


admin.site.register(Attendence,AttendenceAdmin)